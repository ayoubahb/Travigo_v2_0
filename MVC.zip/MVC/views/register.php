<?php

if (isset($_POST['submit'])) {
  $admin = new UsersController();
  $admin->register();
}


?>

<div class="container">
  <div class="row mt-5">
    <div class="col-md-6 mx-auto">
      <?php include('./views/includes/alerts.php') ?>
      <div class="card">
        <div class="card-header">
          <h3 class="text-center">Register</h3>
        </div>
        <div class="card-body bg-light">
          <form method="post" class="mx-1 mx-md-4">
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="fas fa-user fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <label class="form-label" for="form3Example1c">Full Name</label>
                <input type="text" id="form3Example1c" class="form-control" name="fullname"/>
              </div>
            </div>

            <div class="d-flex flex-row align-items-center mb-4">
              <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <label class="form-label" for="form3Example3c">Username</label>
                <input type="text" id="form3Example3c" class="form-control" name="username"/>
              </div>
            </div>

            <div class="d-flex flex-row align-items-center mb-4">
              <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
              <div class="form-outline flex-fill mb-0">
                <label class="form-label" for="form3Example4c">Password</label>
                <input type="password" id="form3Example4c" class="form-control"name="password"/>
              </div>
            </div>

            <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
              <button type="submit" name="submit" class="btn btn-primary btn-lg">Register</button>
            </div>
          </form>
        </div>
        <div class="card-footer text-center">
          <a href="<?php echo BASE_URL ;?>login" class="btn btn-link">Login</a>
        </div>
      </div>
    </div>
  </div>
</div>