<section id="contact">
			<div class="footer">
				<div class="main">
					<div class="list">
						<h4>Quick Links</h4>
						<ul>
							<li><a href="#">About us</a></li>
							<li><a href="#">Terms & Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Help</a></li>
							<li><a href="#">Tours</a></li>
						</ul>
					</div>

					<div class="list">
						<h4>Support</h4>
						<ul>
							<li><a href="#">About us</a></li>
							<li><a href="#">Terms & Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
							<li><a href="#">Help</a></li>
							<li><a href="#">Tour</a></li>
						</ul>
					</div>

					<div class="list">
						<h4>Contact Info</h4>
						<ul>
							<li><a href="#">98 West 21th Street</a></li>
							<li><a href="#">New York NY 10016</a></li>
							<li><a href="#">+(123)-123-1234</a></li>
							<li><a href="#">info@travigo.com</a></li>
							<li><a href="#">+(123)-123-1234</a></li>
						</ul>
					</div>

					<div class="list">
						<h4>Connect</h4>
						<div class="social">
							<a href="#"><i class="fa-brands fa-facebook"></i></a>
							<a href="#"><i class="fa-brands fa-instagram"></i></a>
							<a href="#"><i class="fa-brands fa-twitter"></i></a>
							<a href="#"><i class="fa-brands fa-linkedin"></i></a>
						</div>
					</div>
				</div>
			</div>

			<div class="end-text">
				<p>Copyright ©2022 All rights reserved | Travigo</p>
			</div>
		</section>
<script src="./views/js/script.js"></script>
</body>
</html>