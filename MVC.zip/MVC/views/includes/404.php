<div class="container">
	<div class="row mt-4">
		<div class="col-md-10 mx-auto">
			<div class="card-body">
				<div class="text-center p-5 rounded bg-secondary">
					<h2 class="text-white">Page Introuvable</h2>
					<a
						href="<?php echo BASE_URL;?>home"
						class="btn btn-outline-secondary text-white"
						>Accueil</a>
				</div>
			</div>
		</div>
	</div>
</div>
