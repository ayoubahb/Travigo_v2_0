<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- CSS only -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"> -->
  <link rel="stylesheet" href="./views/css/style.css">  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
  <title>Document</title>
</head>
<body>
  <header>
    <a href="home" class="w_logo"
      ><img src="./views/img/logo/white_logo.png" alt="logo" width="130px"
    /></a>
    <a href="home" class="b_logo unvisible"
      ><img src="./views/img/logo/black_logo.png" alt="logo" width="130px"
    /></a>
    <div class="bx bx-menu" id="menu-icon"></div>

    <ul class="navbar">
      <li><a href="home">Home</a></li>
      <li><a href="tours">Tours</a></li>
      <li><a href="about">About</a></li>
      <li><a href="contact">Contact Us</a></li>
    </ul>
  </header>
  <section class="home" id="home">
    <div class="home-text">
      <h1>
        Travigo <br />
        Travel
      </h1>
      <p>
        Explore our trips and live The Good Life with Travigo <br />
        Tours that make you fall in love with the world.
      </p>
      <a href="#" class="home-btn">Let's go now</a>
    </div>
  </section>

