<?php
require_once './views/includes/header.php';
?>

<section class="search">
			<div class="text">
				<h2>Search for a tour</h2>
			</div>
			<form>
				<div>
					<select name="" id="">
						<option value="" selected>Select destination</option>
						<option value="">Asia</option>
						<option value="">Africa</option>
						<option value="">Europe</option>
						<option value="">South America</option>
						<option value="">North America</option>
					</select>
				</div>
				<div>
					<input
						type="text"
						name=""
						id=""
						placeholder="Tour Date"
						onfocus="(this.type ='Date')"
					/>
				</div>
				<button>Submit</button>
			</form>
		</section>

		<!--destination section--->
		<section class="destination" id="destination">
			<div class="title">
				<h2>
					Our Most Popular <br />
					Destination!
				</h2>
			</div>

			<div class="destination-content">
				<div class="col-content">
					<img src="./views/img/img-1.jpg" alt="Destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-2.jpg" alt="Destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-3.jpg" alt="Destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>
			</div>
		</section>

		<!--Package section--->
		<section class="package" id="package">
			<div class="title">
				<h2>Tours</h2>
			</div>

			<div class="package-content">
				<div class="box">
					<div class="thum">
						<img src="./views/img/img1.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>London</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img2.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>New York</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img3.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img1.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>New York</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img2.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img3.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img1.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>New York</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img2.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img3.png" alt="Destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!--Newsletter--->
		<section class="newsletter">
			<div class="news-text">
				<h2>Newsletter</h2>
				<p>
					Subscribe For more HTML, CSS, and <br />
					coding tutorials
				</p>
			</div>

			<div class="send">
				<form>
					<input type="email" placeholder="Write Your Email" required />
					<input type="submit" value="Submit" />
				</form>
			</div>
		</section>

<?php
require_once './views/includes/footer.php';
?>