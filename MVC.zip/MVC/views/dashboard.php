

<?php
require_once './views/includes/header1.php';


$data = new EmployesController();

$employes = $data->getAllEmployes();

?>

<div class="container">
  <div class="row mt-5">
    <div class="col-md-10 mx-auto">
      <?php include('./views/includes/alerts.php'); ?>
      <div class="card">
        <div class="card-body bg-light">
          <a class="btn btn-sm btn-primary me-2 mb-2" href="<?php echo BASE_URL;?>add">
            <i class="fas fa-plus"></i>
          </a>
          <a class="btn btn-sm btn-outline-secondary me-2 mb-2" href="<?php echo BASE_URL;?>logout" title="Logout">
            <i class="fas fa-user"></i>
            <span><?php echo $_SESSION['username'];?></span>
          </a>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Destination</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>

              </tr>
            </thead>
            <tbody>
              <?php foreach($employes as $employe):?>
                <tr>
                  <td><?php echo $employe['trip_id']; ?></td>
                  <td><?php echo $employe['trip_name']; ?></td>
                  <td><?php echo $employe['trip_destination'];?></td>
                  <td><?php echo $employe['trip_date'];?></td>
                  <td class="d-flex">
                    <form action="update" method = "post" class="me-2">
                      <input type="hidden" name="id" value="<?php echo $employe['trip_id'];?>">
                      <button class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></button>
                    </form>
                    <form action="delete" method = "post">
                      <input type="hidden" name="id" value="<?php echo $employe['trip_id'];?>">
                      <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
                <?php endforeach;?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
require_once './views/includes/footer1.php';

?>