<?php

if (isset($_POST['id'])) {
  $existEmploye = new EmployesController();
  
  $employes = $existEmploye->getOneEmployes();
}else{
  Redirect::to('dashboard');

}
if (isset($_POST['submit'])) {
  $existEmploye = new EmployesController();
  
  $employes = $existEmploye->updateEmployes();
}

?>

<div class="container">
  <div class="row mt-5">
    <div class="col-md-10 mx-auto">
      <div class="card">
        <div class="card-header">Update a tour</div>
        <div class="card-body bg-light">
          <a class="btn btn-sm btn-secondary me-2 mb-2" href="<?php echo BASE_URL;?>dashboard">
            <i class="fas fa-home"></i>
          </a>
          <form method="post">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo $employes->trip_name ?>">
            </div>

            <div class="form-group">
              <label for="destination">Destination</label>
              <input type="text" name="destination" class="form-control" placeholder="Destination" value="<?php echo $employes->trip_destination ?>">
              <input type="hidden" name="id" value="<?php echo $employes->trip_id ?>">

            </div>

            <div class="form-group">
              <label for="name">Date</label>
              <input type="date" name="date" class="form-control">
            </div>

            <div class="form-group">
              <label for="name">Image</label>
              <input type="text" name="img" class="form-control"value="<?php echo $employes->trip_img ?>">
            </div>
            
            <div class="form-group">
              <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>