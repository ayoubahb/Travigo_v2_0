<?php 

UsersController::logout();
Redirect::to('login');
