<?php
require_once './views/includes/header.php';
?>
    <section class="contact">
			<div class="text">
				<h2>Contact us</h2>
				<p>
					feel free to contact us any time . we will get back to you as soon as
					we can.
				</p>
			</div>
			<form>
				<div>
					<label>Name</label>
					<br />
					<input type="text" name="name" />
				</div>
				<div>
					<label>Company</label>
					<br />
					<input type="text" name="company" />
				</div>
				<div>
					<label>Email Address</label>
					<br />
					<input type="email" name="email" />
				</div>
				<div>
					<label>Subject</label>
					<br />
					<input type="text" name="phone" />
				</div>
				<div class="full">
					<label>Message</label>
					<br />
					<textarea name="message" rows="5"></textarea>
				</div>
				<div class="btn">
					<button>Submit</button>
				</div>
			</form>
		</section>

		<!--Newsletter--->
		<section class="newsletter">
			<div class="news-text">
				<h2>Newsletter</h2>
				<p>
					Subscribe For more HTML, CSS, and <br />
					coding tutorials
				</p>
			</div>

			<div class="send">
				<form>
					<input type="email" placeholder="Write Your Email" required />
					<input type="submit" value="Submit" />
				</form>
			</div>
		</section>
    <?php
require_once './views/includes/footer.php';
?>