<?php
require_once './views/includes/header.php';
?>
<section class="container">
			<div class="text">
				<h2>
					Start Your Vacation <br />
					with Lots of Services!
				</h2>
			</div>

			<div class="row-items">
				<div class="container-box">
					<div class="container-img">
						<img src="./views/img/trip1.png" alt="icon Picture" />
					</div>
					<h4>Ship Cruises</h4>
					<p>150 Properties</p>
				</div>

				<div class="container-box">
					<div class="container-img">
						<img src="./views/img/trip2.png" alt="icon Picture" />
					</div>
					<h4>Food Tours</h4>
					<p>150 Properties</p>
				</div>

				<div class="container-box">
					<div class="container-img">
						<img src="./views/img/trip3.png" alt="icon Picture" />
					</div>
					<h4>Summer Rest</h4>
					<p>150 Properties</p>
				</div>
			</div>
		</section>

		<!--Package section--->
		<section class="package" id="package">
			<div class="title">
				<h2>
					Our Upcoming <br />
					Tour Package
				</h2>
			</div>

			<div class="package-content">
				<div class="box">
					<div class="thum">
						<img src="./views/img/img1.png" alt="Tour destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>London</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img2.png" alt="Tour destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>New York</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>

				<div class="box">
					<div class="thum">
						<img src="./views/img/img3.png" alt="Tour destination Picture" />
						<h3>$499</h3>
					</div>

					<div class="dest-content">
						<div class="location">
							<h4>Dubai</h4>
							<p>4h - 5h</p>
						</div>
						<div class="stars">
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
							<a href="#"><i class="bx bxs-star"></i></a>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!--destination section--->
		<section class="destination" id="destination">
			<div class="title">
				<h2>
					Our Most Popular <br />
					Destination!
				</h2>
			</div>

			<div class="destination-content">
				<div class="col-content">
					<img src="./views/img/img-1.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-2.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-3.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-4.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-5.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>

				<div class="col-content">
					<img src="./views/img/img-6.jpg" alt="Tour destination Picture" />
					<h5>Machu Picchu</h5>
					<p>PERU</p>
				</div>
			</div>
		</section>

		<!--Newsletter--->
		<section class="newsletter">
			<div class="news-text">
				<h2>Newsletter</h2>
				<p>
					Subscribe For more HTML, CSS, and <br />
					coding tutorials
				</p>
			</div>

			<div class="send">
				<form>
					<input type="email" placeholder="Write Your Email" required />
					<input type="submit" value="Submit" />
				</form>
			</div>
		</section>
<?php
require_once './views/includes/footer.php';
?>