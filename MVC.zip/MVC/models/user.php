<?php

class User {

  static public function createUser($data){
    $stmt = DB::connect()->prepare('INSERT INTO admin(admin_fullname,admin_username,admin_password) VALUES (:admin_fullname,:admin_username,:admin_password)');
    $stmt->bindParam(':admin_fullname',$data['admin_fullname']);
    $stmt->bindParam(':admin_username',$data['admin_username']);
    $stmt->bindParam(':admin_password',$data['admin_password']);

    if($stmt->execute()){
      return 'ok';
    }else{
      return 'error';
    }
    $stmt->close();
    $stmt=null;
  }

  static public function login($data){

    $username = $data['admin_username'];
    try {
      $query = 'SELECT * FROM admin WHERE admin_username = :admin_username';
      $stmt = DB::connect()->prepare($query);
      $stmt->execute(array(":admin_username" =>$username));
      $user = $stmt->fetch(PDO::FETCH_OBJ);
      return $user;

    } catch (PDOException $e) {
      echo 'error' .$e->getMessage();
    }
  }

}
?>