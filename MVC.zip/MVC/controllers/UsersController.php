<?php

class UsersController{
  
  public function auth(){
    if (isset($_POST['submit'])) {
      $data = array(
        'admin_username' => $_POST['username']
      );

      $result = User::login($data);
      if ($result->admin_username === $_POST['username'] && password_verify($_POST['password'],$result->admin_password)) {
      $_SESSION['logged'] = true;
      $_SESSION['username'] = $result->admin_username;
      Redirect::to('dashboard');
      
      }else {
        Session::set('error','username or password incorrect');
        Redirect::to('login');
      }
    }
  }

  public function register(){
    if (isset($_POST['submit'])) {
      $hashedPwd = password_hash($_POST['password'],PASSWORD_DEFAULT);
      $data = array(
        'admin_fullname'        => $_POST['fullname'],
        'admin_username'        => $_POST['username'],
        'admin_password'        => $hashedPwd
      );
      $result = User::createUser($data);
      if ($result === 'ok' ) {
        Session::set('success','Account created');
        Redirect::to('login');
      }else {
        echo $result;
      }
    }
  }

  static public function logout(){
    session_destroy();
  }
  
}

