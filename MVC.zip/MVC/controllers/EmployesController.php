<?php

class EmployesController{
  
  public function getAllEmployes(){
    $employes = Employe::getAll();
    return $employes;
  }
  
  
  public function getOneEmployes(){
    if (isset($_POST['id'])) {
      $data = array(
        'id' => $_POST['id']
      );
      $employes = Employe::getEmploye($data);
      return $employes;
    }
  }
  
  public function addEmployes(){
    if (isset($_POST['submit'])) {
      
      $img = $_FILES['img']['name'];
      
      $tmp_name = $_FILES['img']['tmp_name'];
      $folder = "./view/upload_img/" .$img;
      
      move_uploaded_file($tmp_name,$folder);
      

      $data = array(
        'trip_name'        => $_POST['name'],
        'trip_destination' => $_POST['destination'],
        'trip_date'        => $_POST['date'],
        'trip_img'         => $folder
      );
      $result = Employe::add($data);
      if ($result === 'ok' ) {
        Session::set('success','Employe added');
        Redirect::to('dashboard');
      }else {
        echo $result;
      }
    }
  }

  public function updateEmployes(){
    if (isset($_POST['submit'])) {
      $data = array(
        'trip_id'          => $_POST['id'],
        'trip_name'        => $_POST['name'],
        'trip_destination' => $_POST['destination'],
        'trip_date'        => $_POST['date'],
        'trip_img'         => $_POST['img'],
      );
      $result = Employe::update($data);
      if ($result === 'ok' ) {
        Session::set('success','Employe modified');

        Redirect::to('dashboard');
      }else {
        echo $result;
      }
    }
  }

  public function deleteEmployes(){
    if (isset($_POST['id'])) {
      $data = array(
        'id' => $_POST['id']
      );
      $result = Employe::delete($data);
      if ($result === 'ok' ) {
        Session::set('success','Employe deleted');
        Redirect::to('dashboard');
      }else {
        echo $result;
      }
    }
  }
}

